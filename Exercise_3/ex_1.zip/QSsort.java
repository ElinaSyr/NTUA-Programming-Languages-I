import java.util.*;
import java.io.*;


public class QSsort implements State {
  private ArrayList<Integer> QList;
  private ArrayList<Integer> SList; 
  //private ArrayList<Character> Moves; 
  private char Moves;
  // The previous state.
  private State previous;
  

    //constructor
  public QSsort( ArrayList<Integer> q, ArrayList<Integer> s,char m,State p) {
    QList = q;
    SList = s;
    Moves = m;
    previous = p;
  }

  static public QSsort ZebraStateQ(QSsort prev) {
    ArrayList<Integer> q = new ArrayList<Integer>(prev.QList);
    ArrayList<Integer> s = new ArrayList<Integer>(prev.SList);
    s.add(0,q.remove(0));
    return new QSsort(q,s,'Q',prev);
  }
  
  static public QSsort ZebraStateS(QSsort prev) { 
    prev.QList.add(prev.SList.remove(0));
    return new QSsort(prev.QList,prev.SList,'S',prev);
  }

  @Override
  public boolean isFinal() {
    if (!this.SList.isEmpty()){
        return false; 
    }
    else {
        if (check_sort(this)) {
            //System.out.println("sorted");
            return true; 
        }
        else {
            return false; 
        }
    }
  }
  
  static public boolean check_sort(QSsort pr) {
      ArrayList<Integer> q = pr.QList;
      for (int i = 0; i < q.size() - 1; i++) {
        int x = q.get(i);
        int y = q.get(i+1);
        if (x > y)
            return false;
    }
    return true; 
  }

  @Override
  public Collection<State> next() {
    Collection<State> states = new ArrayList<>();
    if (!this.QList.isEmpty() && !this.SList.isEmpty() && this.QList.get(0)==this.SList.get(0)){
        states.add(ZebraStateQ( this ));
        this.QList.clear();
        this.SList.clear();
        return states;
    }
    if (!this.QList.isEmpty()) { 
        states.add(ZebraStateQ(this));
    } 
    if (!this.SList.isEmpty()) { 
        states.add(ZebraStateS(this));
    }
    return states; 
  }


  @Override
  public char getMoves() {
    return Moves;
  }
  @Override
  public State getPrevious() {
    return previous;
  }
  
  // @Override
  // public String toString() {
  //   StringBuilder sb = new StringBuilder("State: ");
  //   sb.append("QList=").append(QList ? "e" : "w");
  //   sb.append(", SList=").append(SList ? "e" : "w");
  //   sb.append(", Moves=").append(Moves ? "e" : "w");
  //   return sb.toString();
  // }


  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    QSsort other = (QSsort) o;
  
    return this.QList.equals(other.QList) && this.SList.equals(other.SList) && this.Moves == other.Moves;
  }

  //Ηashing: consider only the positions of the four players.
  @Override
  public int hashCode() {
    return Objects.hash(SList,QList,Moves);
  }
  
  private static void printSolution(State s) {
    if (s.getPrevious() != null) {
      printSolution(s.getPrevious());
    }
    //System.out.println(str.substring(1, str.length()-1).replaceAll(", ",""));
    if (s.getPrevious() != null){
    System.out.print(s.getMoves());}
  }
  public static void main  (String args[]) throws Exception{
      ArrayList<Integer> Q = new ArrayList<Integer>();
      File file = new File(args[0]);
      try {BufferedReader br = new BufferedReader(new FileReader(file)); 
      String st1 = br.readLine();
      String st = br.readLine();
      Scanner scanner = new Scanner(st);
      while (scanner.hasNextInt()) {
        Q.add(scanner.nextInt());
     }
      ArrayList<Integer> S = new ArrayList<Integer>();
      //ArrayList<Character> M = new ArrayList<Character>();
      QSsort initial = new QSsort(Q,S,(char) 0,null);
      if (check_sort(initial)) System.out.println("empty");
      else{
      //System.out.println(initial.QList);
      Solver solver = new ZBFSolver();
      State result = solver.solve(initial);
      if (result == null) {
      System.out.println("No solution found.");
    } 
    else {
      printSolution(result);
      }}}
     catch (Exception e){
         e.printStackTrace();
     }
      
  }  
}                      