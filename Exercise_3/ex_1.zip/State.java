import java.util.*;

public interface State {
  public boolean isFinal();
  public Collection<State> next();
  public State getPrevious();
  public char getMoves();
}                            